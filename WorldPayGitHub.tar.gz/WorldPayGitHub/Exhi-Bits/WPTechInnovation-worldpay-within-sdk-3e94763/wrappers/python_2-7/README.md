# WorldpayWithin Python 2.7 Wrapper

A Python 2.7 wrapper for the WorldpayWithin IoT payment SDK.

Please see the following files for examples of usage:
* runConsumer.py
* runProducer.py
* runProducerCallbacks.py

In order to have this library start the RPC Agent automatically then you will need to provide it in this directory and named `rpc-agent`. The binary will need to be the version for the OS/Architecture that you plan on running your application.
