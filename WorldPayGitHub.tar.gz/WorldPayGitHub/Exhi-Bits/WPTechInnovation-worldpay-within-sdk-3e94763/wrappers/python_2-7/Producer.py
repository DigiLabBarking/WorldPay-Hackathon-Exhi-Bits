import os
from os import listdir
from os.path import isfile, join
onlyfiles = [f for f in listdir('../../../../Share/') if isfile(join('../../../../Share/', f))]
for x in onlyfiles:
    os.remove('../../../../Share/'+x)
    x = x.replace('.txt','')
    option = x
try:
    x = option
except NameError:
    option = '1'
print(option)
"""
if option == '1':
    import runProducerCallbacks1.py
    quit()
elif option == '2':
    import runProducerCallbacks2.py
    quit()
elif option == '3':
    import runProducerCallbacks3.py
    quit()
else:
    print("Try again")
"""
