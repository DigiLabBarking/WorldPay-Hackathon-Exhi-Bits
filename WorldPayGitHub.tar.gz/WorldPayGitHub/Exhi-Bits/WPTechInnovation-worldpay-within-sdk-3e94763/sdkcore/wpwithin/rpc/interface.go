package rpc

// Service defines functions for the RPC service
type Service interface {
	Start() error
}
