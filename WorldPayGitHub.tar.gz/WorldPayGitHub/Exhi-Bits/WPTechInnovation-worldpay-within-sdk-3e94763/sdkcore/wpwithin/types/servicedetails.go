package types

// ServiceDetails Details of a service
type ServiceDetails struct {
	ServiceID          int
	ServiceDescription string
	ServiceName        string
}
